package com.project.saveoEclipse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaveoEclipseApplicationTests {

	@Test
	void contextLoads() {
	}

}
