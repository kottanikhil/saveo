package com.project.dao;

import com.project.model.SmallScale;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SmallScaleRepository extends JpaRepository<SmallScale , String> {
}
